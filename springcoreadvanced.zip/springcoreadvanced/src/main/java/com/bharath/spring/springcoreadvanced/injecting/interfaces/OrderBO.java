package com.bharath.spring.springcoreadvanced.injecting.interfaces;

public interface OrderBO {
	
	void placeOrder();

}
